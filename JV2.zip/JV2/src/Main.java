public class Main {
    public static void main(String[] args) {System.out.println("Hello world!");
        char myLetter = 'G';
        int myNum = 89;
        byte myByte = 4;
        short myShort = 56;
        float myFloat = 4.7333436f;
        double myDouble = 4.355453532;
        long myLong = 12121l;










    }
