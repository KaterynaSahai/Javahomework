public class Main {
    public static void main(String[] args) {
        int abc=345;
        System.out.println(abc);
        int a=abc/100;
        System.out.println(a);
        int b=abc%100/10;
        System.out.println(b);
        int c =abc%10;
        System.out.println(c);

        int n=987;
        System.out.println(n);
        System.out.println(n/100);
        System.out.println(n%100/10);
        System.out.println(n%10);



    }
}